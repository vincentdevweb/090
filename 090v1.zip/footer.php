<ul class="nav nav-pills nav-fill">
  <li class="nav-item">
    <a class="nav-link link-info" href="#">Mentions légales</a>
  </li>
  <li class="nav-item">
    <a class="nav-link link-info" href="#">Chartes</a>
  </li>
  <li class="nav-item">
    <a class="nav-link link-info" href="#">Politique de confidentialité</a>
  </li>
  <li class="nav-item">
    <a class="nav-link link-info" href="#">Gestions des cookies</a>
  </li>
  <li class="nav-item">
    <a class="nav-link link-info" href="#">Conditions générales</a>
  </li>
  <li class="nav-item">
    <a class="nav-link link-info" href="#">Aide (FAQ)</a>
  </li>
  <li class="nav-item">
    <a class="nav-link disable link-info" aria-current="page" href="#">Retour Haut de Page</a>
  </li>
</ul>