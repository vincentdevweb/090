<?php
$conf = [
    'db' => [
        'host' => 'localhost',
        'database' => 'blogsystem',
        'user' => 'root',
        'password' => 'snoopy'
    ]
];
